package service;

import model.User;
import responsitory.UsersResponsitory;

public class LoginService {
    public boolean checkLogin(String email, String password){
        UsersResponsitory usersResponsitory = new UsersResponsitory();
        int count = usersResponsitory.countUsersByEmailAndPassword(email, password);
        return count > 0;
    }


}
