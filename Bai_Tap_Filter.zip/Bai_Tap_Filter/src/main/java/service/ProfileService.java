package service;

import model.User;
import responsitory.UsersResponsitory;

public class ProfileService {
    public User getUser(String email){
        UsersResponsitory usersResponsitory = new UsersResponsitory();
        return usersResponsitory.getUsersByEmail(email);
    }
}
