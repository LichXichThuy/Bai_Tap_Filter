package responsitory;

import config.MysqlConfig;
import model.User;
import model.UsersEnum;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsersResponsitory {
    public int countUsersByEmailAndPassword(String email, String password){
        int count = 0;
        Connection connection = MysqlConfig.getConnection();
        String query = "select count(*) as count from users u where u.email = ? and password = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1,email);
            statement.setString(2,password);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()){
                count = resultSet.getInt("count");
            }
        }catch (Exception e){
            System.err.println("Đây là lỗi PreparedStatement :" + e.getMessage());
        }
        return count;
    }

    public User getUsersByEmail(String email){
        User user = new User();
        Connection connection = MysqlConfig.getConnection();
        String query = "select * from users u where u.email = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1,email);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()){
                user.setId(resultSet.getInt((UsersEnum.ID.getValue())));
                user.setEmail(resultSet.getString(UsersEnum.EMAIL.getValue()));
                user.setFullname(resultSet.getString(UsersEnum.FULLNAME.getValue()));
                user.setAvatar(resultSet.getString(UsersEnum.AVATAR.getValue()));
                user.setRole_id(resultSet.getInt(UsersEnum.ROLE_ID.getValue()));
            }
        }catch (Exception e){
            System.err.println("Đây là lỗi PreparedStatement :" + e.getMessage());
        } finally {
            try {
                connection.close();
            }catch (Exception e){

            }
        }
        return user;
    }
}
