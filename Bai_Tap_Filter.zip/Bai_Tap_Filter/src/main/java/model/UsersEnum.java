package model;

public enum UsersEnum {
    ID("id"),
    EMAIL("email"),
    PASSWORD("password"),
    FULLNAME("fullname"),
    AVATAR("avatar"),
    ROLE_ID("role_id");
    private String value;
    UsersEnum(String value){this.value = value; }
    public String getValue() {
        return value;
    }
}
